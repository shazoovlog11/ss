#!/bin/bash

echo "============================================"
echo "  Fiverr Bot - Ubuntu VPS Setup Script"
echo "============================================"

# Update system
echo "[1/7] Updating system packages..."
sudo apt-get update -y
sudo apt-get upgrade -y

# Install Node.js 20
echo "[2/7] Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

echo "Node.js version: $(node --version)"
echo "NPM version: $(npm --version)"

# Install Google Chrome
echo "[3/7] Installing Google Chrome..."
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
sudo sh -c 'echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list'
sudo apt-get update -y
sudo apt-get install -y google-chrome-stable
echo "Chrome version: $(google-chrome --version)"

# Install system dependencies for Playwright
echo "[4/7] Installing system dependencies..."
sudo apt-get install -y \
  libgconf-2-4 \
  libxss1 \
  libxtst6 \
  xvfb \
  libgbm-dev \
  libasound2 \
  libatk1.0-0 \
  libcairo2 \
  libcups2 \
  libdbus-1-3 \
  libexpat1 \
  libfontconfig1 \
  libgcc1 \
  libglib2.0-0 \
  libgtk-3-0 \
  libnspr4 \
  libnss3 \
  libpango-1.0-0 \
  libpangocairo-1.0-0 \
  libstdc++6 \
  libx11-6 \
  libx11-xcb1 \
  libxcb1 \
  libxcomposite1 \
  libxcursor1 \
  libxdamage1 \
  libxext6 \
  libxfixes3 \
  libxi6 \
  libxrandr2 \
  libxrender1 \
  libxss1 \
  libxtst6 \
  ca-certificates \
  fonts-liberation \
  fonts-noto-color-emoji \
  libappindicator3-1 \
  libindicator7 \
  lsb-release \
  xdg-utils \
  wget \
  curl \
  unzip \
  fonts-ipafont-gothic \
  fonts-wqy-zenhei \
  fonts-thai-tlwg \
  fonts-freefont-ttf

# Install PM2
echo "[5/7] Installing PM2..."
sudo npm install -g pm2

# Install project dependencies
echo "[6/7] Installing Node.js dependencies..."
npm install

# Install Playwright browsers
echo "[7/7] Installing Playwright Chromium..."
npx playwright install chromium
npx playwright install-deps chromium

# Create necessary directories
mkdir -p screenshots logs browser_profile

# Set up PM2 startup
pm2 startup
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME

echo ""
echo "============================================"
echo "  Installation Complete!"
echo "============================================"
echo ""
echo "Next steps:"
echo "1. Make sure .env has all your credentials filled in"
echo "2. Run: chmod +x start.sh && ./start.sh"
echo "3. Monitor: pm2 logs fiverr-bot"
echo ""
echo ".env variables needed:"
echo "  TELEGRAM_BOT_TOKEN=your_token"
echo "  TELEGRAM_CHAT_ID=your_chat_id"
echo "  FIVERR_USERNAME=your_email_or_username"
echo "  FIVERR_PASSWORD=your_password"
echo "  FIVERR_DASHBOARD_URL=https://www.fiverr.com/seller_dashboard"
echo "  SCREENSHOTS_DIR=./screenshots"
echo "  PROFILE_DIR=./browser_profile"
echo "  LOG_LEVEL=info"
echo ""
