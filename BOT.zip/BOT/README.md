# Fiverr 24/7 Presence Bot

Keeps your Fiverr seller dashboard active 24/7 with human-like behavior using automatic email/password login.

## Features
- Automatic login with email/password (no cookies needed)
- Undetectable browser automation (Playwright + Stealth)
- Real Chrome fingerprint spoofing
- Human-like mouse movements (Bezier curves)
- Realistic scroll patterns
- Random refresh intervals (50s - 2min)
- Screenshot after every refresh sent to Telegram
- Auto-recovery on errors
- Automatic re-login if session expires
- Hourly heartbeat messages to Telegram

## Setup on Ubuntu VPS

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd fiverr-bot
chmod +x install.sh
./install.sh
```

### 2. Configure .env

Your `.env` file should contain:

```
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_CHAT_ID=your_telegram_chat_id
FIVERR_USERNAME=your_fiverr_email_or_username
FIVERR_PASSWORD=your_fiverr_password
FIVERR_DASHBOARD_URL=https://www.fiverr.com/seller_dashboard
SCREENSHOTS_DIR=./screenshots
PROFILE_DIR=./browser_profile
LOG_LEVEL=info
```

### 3. Start Bot

```bash
chmod +x start.sh
./start.sh
```

## PM2 Commands

```bash
pm2 logs fiverr-bot        # View live logs
pm2 status                 # Check status
pm2 restart fiverr-bot     # Restart
pm2 stop fiverr-bot        # Stop
pm2 monit                  # Monitor resources
```

## Telegram Setup

1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. Create a new bot and copy the token → set as `TELEGRAM_BOT_TOKEN`
3. Get your chat ID from [@userinfobot](https://t.me/userinfobot) → set as `TELEGRAM_CHAT_ID`

## Notes

- The bot logs in automatically using your Fiverr email/password
- If the session expires during runtime, the bot re-logs in automatically
- Screenshots are sent to Telegram after every page refresh
- Old screenshots are auto-cleaned (keeps last 50)
