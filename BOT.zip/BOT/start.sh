#!/bin/bash

echo "Starting Fiverr 24/7 Presence Bot..."

# Check .env exists
if [ ! -f ".env" ]; then
  echo "ERROR: .env file not found. Please create it with your credentials."
  exit 1
fi

# Check required env vars
source .env
if [ -z "$FIVERR_USERNAME" ] || [ -z "$FIVERR_PASSWORD" ]; then
  echo "ERROR: FIVERR_USERNAME and FIVERR_PASSWORD must be set in .env"
  exit 1
fi
if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ]; then
  echo "ERROR: TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID must be set in .env"
  exit 1
fi

# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 config
pm2 save

echo ""
echo "Bot started successfully!"
echo "Commands:"
echo "  pm2 logs fiverr-bot     - View live logs"
echo "  pm2 status              - Check status"
echo "  pm2 restart fiverr-bot  - Restart bot"
echo "  pm2 stop fiverr-bot     - Stop bot"
echo "  pm2 monit               - Monitor resources"
echo ""
