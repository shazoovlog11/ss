require('dotenv').config();
const path = require('path');
const fs = require('fs');
const logger = require('./logger');
const BrowserManager = require('./browserManager');
const TelegramNotifier = require('./telegramNotifier');
const ScreenshotManager = require('./screenshotManager');
const {
  sleep,
  humanSleep,
  gaussianRandom,
  clamp,
  getNextRefreshInterval,
  humanRefresh,
  simulateReadingDashboard,
  simulateIdleBehavior
} = require('./humanBehavior');

const DASHBOARD_URL = process.env.FIVERR_DASHBOARD_URL || 'https://www.fiverr.com/seller_dashboard';
const SCREENSHOTS_DIR = process.env.SCREENSHOTS_DIR || './screenshots';
const PROFILE_DIR = process.env.PROFILE_DIR || './browser_profile';
const TELEGRAM_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;
const FIVERR_USERNAME = process.env.FIVERR_USERNAME;
const FIVERR_PASSWORD = process.env.FIVERR_PASSWORD;

class FiverrBot {
  constructor() {
    this.browserManager = new BrowserManager(path.resolve(PROFILE_DIR));
    this.telegram = new TelegramNotifier(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID);
    this.screenshotManager = new ScreenshotManager(path.resolve(SCREENSHOTS_DIR));
    this.page = null;
    this.refreshCount = 0;
    this.startTime = Date.now();
    this.isRunning = false;
    this.consecutiveErrors = 0;
    this.maxConsecutiveErrors = 5;
    this.heartbeatInterval = null;
  }

  async initialize() {
    logger.info('='.repeat(60));
    logger.info('Fiverr 24/7 Presence Bot Starting...');
    logger.info('='.repeat(60));

    if (!FIVERR_USERNAME || !FIVERR_PASSWORD) {
      throw new Error('FIVERR_USERNAME and FIVERR_PASSWORD environment variables are required');
    }

    // Launch browser
    const { page } = await this.browserManager.launch();
    this.page = page;

    // Login with email/password
    logger.info(`Logging in as: ${FIVERR_USERNAME}`);
    await this.browserManager.login(FIVERR_USERNAME, FIVERR_PASSWORD);

    // Navigate to seller dashboard
    await this.navigateToDashboard();

    // Verify we're on the dashboard
    const isOnDashboard = await this.verifyDashboard();
    if (!isOnDashboard) {
      logger.warn('Could not confirm dashboard - proceeding anyway');
    }

    await this.telegram.sendStartupMessage();

    // Heartbeat every 1 hour
    this.heartbeatInterval = setInterval(async () => {
      const uptime = Date.now() - this.startTime;
      await this.telegram.sendHeartbeat(this.refreshCount, uptime);
    }, 3600000);

    this.isRunning = true;
  }

  async navigateToDashboard(isRefresh = false) {
    try {
      if (!isRefresh) {
        logger.info(`Navigating to dashboard: ${DASHBOARD_URL}`);
        await this.page.goto(DASHBOARD_URL, {
          waitUntil: 'networkidle',
          timeout: 60000
        });
      }

      await humanSleep(gaussianRandom(2000, 500));
      await this.dismissOverlays();

      return true;
    } catch (err) {
      logger.error(`Navigation error: ${err.message}`);
      return false;
    }
  }

  async dismissOverlays() {
    try {
      const overlaySelectors = [
        '[data-testid="close-button"]',
        '.modal-close',
        '.close-btn',
        '[aria-label="Close"]',
        '.cookie-consent button',
        '#onetrust-accept-btn-handler'
      ];

      for (const selector of overlaySelectors) {
        try {
          const element = await this.page.$(selector);
          if (element) {
            const isVisible = await element.isVisible();
            if (isVisible) {
              await element.click();
              await humanSleep(500);
              logger.debug(`Dismissed overlay: ${selector}`);
            }
          }
        } catch (e) {}
      }
    } catch (err) {}
  }

  async verifyDashboard() {
    try {
      await humanSleep(2000);

      const currentUrl = this.page.url();
      logger.info(`Current URL: ${currentUrl}`);

      if (currentUrl.includes('/login') || currentUrl.includes('/join')) {
        logger.warn('Redirected to login page');
        return false;
      }

      const dashboardSelectors = [
        '.seller-dashboard',
        '[data-testid="seller-dashboard"]',
        '.dashboard-header',
        '#seller-dashboard',
        '.stats-overview'
      ];

      for (const selector of dashboardSelectors) {
        try {
          const el = await this.page.$(selector);
          if (el) {
            logger.info(`Dashboard confirmed via: ${selector}`);
            return true;
          }
        } catch (e) {}
      }

      const title = await this.page.title();
      logger.info(`Page title: ${title}`);

      if (title.toLowerCase().includes('dashboard') ||
          title.toLowerCase().includes('seller') ||
          currentUrl.includes('seller_dashboard')) {
        return true;
      }

      logger.info('Dashboard verification inconclusive - assuming success');
      return true;
    } catch (err) {
      logger.error(`Dashboard verification error: ${err.message}`);
      return false;
    }
  }

  async performRefresh() {
    try {
      logger.info(`\n${'='.repeat(50)}`);
      logger.info(`Performing refresh #${this.refreshCount + 1}`);

      const preRefreshBehavior = Math.random();

      if (preRefreshBehavior < 0.4) {
        logger.info('Pre-refresh: scrolling...');
        const { humanScroll } = require('./humanBehavior');
        await humanScroll(this.page);
        await humanSleep(gaussianRandom(1500, 500));
      } else if (preRefreshBehavior < 0.6) {
        await humanSleep(gaussianRandom(2000, 800));
      }

      await humanRefresh(this.page);

      try {
        await this.page.waitForLoadState('networkidle', { timeout: 30000 });
      } catch (e) {
        logger.warn('WaitForNetworkIdle timeout, continuing...');
      }

      await humanSleep(gaussianRandom(1500, 500));

      const currentUrl = this.page.url();
      if (!currentUrl.includes('fiverr.com')) {
        logger.warn(`Unexpected URL after refresh: ${currentUrl}`);
        await this.navigateToDashboard();
      }

      // If redirected back to login, re-authenticate
      if (currentUrl.includes('/login') || currentUrl.includes('/join')) {
        logger.warn('Session expired - re-logging in...');
        await this.telegram.sendMessage('🔑 <b>Session Expired:</b> Re-logging in to Fiverr...');
        await this.browserManager.login(FIVERR_USERNAME, FIVERR_PASSWORD);
        await this.navigateToDashboard();
      }

      await this.dismissOverlays();

      this.refreshCount++;
      logger.info(`Refresh #${this.refreshCount} completed`);

      const screenshotPath = await this.screenshotManager.takeScreenshot(
        this.page,
        `refresh_${this.refreshCount}`
      );

      return screenshotPath;
    } catch (err) {
      logger.error(`Refresh error: ${err.message}`);
      throw err;
    }
  }

  async runMainLoop() {
    logger.info('Starting main loop...');

    while (this.isRunning) {
      try {
        const nextInterval = getNextRefreshInterval();

        const readingTime = nextInterval - 5000;
        if (readingTime > 0) {
          await simulateReadingDashboard(this.page, readingTime);
        }

        await humanSleep(gaussianRandom(2000, 1000));

        const screenshotPath = await this.performRefresh();

        const nextRefreshInterval = getNextRefreshInterval();
        if (screenshotPath) {
          await this.telegram.sendRefreshNotification(
            screenshotPath,
            this.refreshCount,
            nextRefreshInterval
          );
        }

        this.consecutiveErrors = 0;

      } catch (err) {
        this.consecutiveErrors++;
        logger.error(`Main loop error (${this.consecutiveErrors}/${this.maxConsecutiveErrors}): ${err.message}`);

        await this.telegram.sendErrorAlert(err.message);

        if (this.consecutiveErrors >= this.maxConsecutiveErrors) {
          logger.error('Too many consecutive errors, attempting full recovery...');
          await this.fullRecovery();
        } else {
          const recoveryDelay = clamp(
            gaussianRandom(30000 * this.consecutiveErrors, 10000),
            30000,
            120000
          );
          logger.info(`Recovery delay: ${(recoveryDelay / 1000).toFixed(0)}s`);
          await sleep(recoveryDelay);

          try {
            await this.page.goto(DASHBOARD_URL, {
              waitUntil: 'domcontentloaded',
              timeout: 30000
            });
          } catch (navErr) {
            logger.error(`Recovery navigation failed: ${navErr.message}`);
          }
        }
      }
    }
  }

  async fullRecovery() {
    logger.info('Attempting full browser recovery...');

    try {
      await this.browserManager.close();
      await sleep(10000);

      const { page } = await this.browserManager.launch();
      this.page = page;

      // Re-login after full recovery
      await this.browserManager.login(FIVERR_USERNAME, FIVERR_PASSWORD);

      await this.page.goto(DASHBOARD_URL, {
        waitUntil: 'networkidle',
        timeout: 60000
      });

      this.consecutiveErrors = 0;
      await this.telegram.sendMessage('🔄 <b>Bot Recovery:</b> Successfully recovered from error state!');
      logger.info('Full recovery successful');
    } catch (err) {
      logger.error(`Full recovery failed: ${err.message}`);
      await this.telegram.sendMessage(`💀 <b>Critical:</b> Recovery failed - ${err.message}`);

      await sleep(60000);
      await this.fullRecovery();
    }
  }

  async start() {
    try {
      await this.initialize();
      await this.runMainLoop();
    } catch (err) {
      logger.error(`Fatal error: ${err.message}`);
      await this.telegram.sendErrorAlert(`Fatal: ${err.message}`);
      process.exit(1);
    }
  }

  async stop() {
    logger.info('Stopping bot...');
    this.isRunning = false;

    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    await this.browserManager.close();
    await this.telegram.sendMessage('🛑 <b>Bot Stopped:</b> Fiverr presence bot has been stopped.');
    logger.info('Bot stopped');
  }
}

module.exports = FiverrBot;
