/**
 * Human behavior simulation engine
 * Generates realistic random delays, movements, and interactions
 */

const logger = require('./logger');

// Gaussian random number generator (Box-Muller transform)
function gaussianRandom(mean = 0, std = 1) {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return mean + std * Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

// Clamp value between min and max
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

// Sleep with exact ms
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Human-like sleep with slight jitter
async function humanSleep(ms, jitterPercent = 0.1) {
  const jitter = ms * jitterPercent;
  const actual = ms + (Math.random() * jitter * 2 - jitter);
  await sleep(Math.max(100, actual));
}

// Generate refresh interval between 50s and 2min with human variation
function getNextRefreshInterval() {
  const intervals = [
    { min: 50000, max: 65000, weight: 25 },   // ~50sec - 1min5sec
    { min: 60000, max: 75000, weight: 30 },   // ~1min - 1min15sec
    { min: 75000, max: 100000, weight: 25 },  // ~1min15sec - 1min40sec
    { min: 100000, max: 120000, weight: 20 }  // ~1min40sec - 2min
  ];

  // Weighted random selection
  const totalWeight = intervals.reduce((sum, i) => sum + i.weight, 0);
  let rand = Math.random() * totalWeight;
  let selected = intervals[0];

  for (const interval of intervals) {
    rand -= interval.weight;
    if (rand <= 0) {
      selected = interval;
      break;
    }
  }

  const base = selected.min + Math.random() * (selected.max - selected.min);
  // Add gaussian noise
  const noise = gaussianRandom(0, (selected.max - selected.min) * 0.1);
  const final = clamp(base + noise, 50000, 120000);

  logger.info(`Next refresh in ${(final / 1000).toFixed(1)}s`);
  return final;
}

// Simulate human mouse movement with bezier curve
async function humanMouseMove(page, startX, startY, endX, endY) {
  const steps = Math.floor(gaussianRandom(25, 8));
  const actualSteps = clamp(steps, 10, 50);

  // Generate bezier control points
  const cp1x = startX + (endX - startX) * 0.25 + gaussianRandom(0, 50);
  const cp1y = startY + (endY - startY) * 0.25 + gaussianRandom(0, 50);
  const cp2x = startX + (endX - startX) * 0.75 + gaussianRandom(0, 50);
  const cp2y = startY + (endY - startY) * 0.75 + gaussianRandom(0, 50);

  for (let i = 0; i <= actualSteps; i++) {
    const t = i / actualSteps;
    const tt = t * t;
    const ttt = tt * t;
    const mt = 1 - t;
    const mtt = mt * mt;
    const mttt = mtt * mt;

    const x = mttt * startX + 3 * mtt * t * cp1x + 3 * mt * tt * cp2x + ttt * endX;
    const y = mttt * startY + 3 * mtt * t * cp1y + 3 * mt * tt * cp2y + ttt * endY;

    await page.mouse.move(Math.round(x), Math.round(y));

    // Variable speed - slower at start and end, faster in middle
    const speedFactor = Math.sin(Math.PI * t);
    const delay = clamp(gaussianRandom(8, 3) / (speedFactor + 0.1), 2, 30);
    await sleep(delay);
  }
}

// Simulate human scrolling behavior
async function humanScroll(page) {
  const scrollPatterns = [
    // Pattern 1: Slow read scroll down
    async () => {
      const scrollAmount = Math.floor(gaussianRandom(300, 100));
      const steps = Math.floor(gaussianRandom(8, 3));
      const actualSteps = clamp(steps, 3, 15);

      for (let i = 0; i < actualSteps; i++) {
        const delta = scrollAmount / actualSteps + gaussianRandom(0, 10);
        await page.mouse.wheel(0, delta);
        await humanSleep(gaussianRandom(150, 50));
      }
    },
    // Pattern 2: Quick scan then stop
    async () => {
      const scrollAmount = Math.floor(gaussianRandom(500, 150));
      await page.mouse.wheel(0, scrollAmount);
      await humanSleep(gaussianRandom(800, 200));
      // Scroll back a bit as if re-reading
      await page.mouse.wheel(0, -Math.floor(scrollAmount * 0.3));
      await humanSleep(gaussianRandom(500, 100));
    },
    // Pattern 3: Small incremental scrolls
    async () => {
      const count = Math.floor(gaussianRandom(5, 2));
      for (let i = 0; i < clamp(count, 2, 10); i++) {
        await page.mouse.wheel(0, Math.floor(gaussianRandom(80, 30)));
        await humanSleep(gaussianRandom(400, 150));
      }
    }
  ];

  const pattern = scrollPatterns[Math.floor(Math.random() * scrollPatterns.length)];
  await pattern();
}

// Simulate idle human behavior (random mouse moves, occasional scrolls)
async function simulateIdleBehavior(page, durationMs) {
  const startTime = Date.now();
  let lastAction = Date.now();

  logger.info(`Simulating idle human behavior for ${(durationMs / 1000).toFixed(1)}s`);

  while (Date.now() - startTime < durationMs) {
    const timeSinceAction = Date.now() - lastAction;
    const waitTime = gaussianRandom(8000, 3000);

    if (timeSinceAction >= waitTime) {
      const action = Math.random();

      try {
        if (action < 0.3) {
          // Random mouse movement
          const viewport = page.viewportSize();
          if (viewport) {
            const x = Math.floor(Math.random() * viewport.width);
            const y = Math.floor(Math.random() * viewport.height);
            const currentPos = { x: Math.floor(viewport.width / 2), y: Math.floor(viewport.height / 2) };
            await humanMouseMove(page, currentPos.x, currentPos.y, x, y);
          }
        } else if (action < 0.5) {
          // Random scroll
          await humanScroll(page);
        } else if (action < 0.6) {
          // Scroll back to top
          const scrollTop = Math.floor(Math.random() * 500);
          await page.mouse.wheel(0, -scrollTop);
          await humanSleep(gaussianRandom(500, 100));
        }
        // else: just wait (doing nothing - very human)

        lastAction = Date.now();
      } catch (err) {
        // Page might be navigating, ignore
      }
    }

    await sleep(500);
  }
}

// Simulate human-like page refresh (not just F5 - mix of methods)
async function humanRefresh(page) {
  const methods = [
    // Method 1: Click address bar and press Enter (most human)
    async () => {
      logger.info('Refresh method: Address bar click + Enter');
      // Move mouse to address bar area (top of browser)
      const viewport = page.viewportSize() || { width: 1366, height: 768 };
      // Simulate clicking somewhere on page first
      const x = Math.floor(Math.random() * viewport.width * 0.8) + viewport.width * 0.1;
      const y = Math.floor(Math.random() * viewport.height * 0.6) + 100;
      await humanMouseMove(page, viewport.width / 2, viewport.height / 2, x, y);
      await humanSleep(gaussianRandom(300, 100));

      // Use keyboard shortcut Ctrl+R (most common)
      await page.keyboard.down('Control');
      await humanSleep(gaussianRandom(50, 20));
      await page.keyboard.press('r');
      await humanSleep(gaussianRandom(50, 20));
      await page.keyboard.up('Control');
    },
    // Method 2: F5 key
    async () => {
      logger.info('Refresh method: F5 key');
      await humanSleep(gaussianRandom(200, 80));
      await page.keyboard.press('F5');
    },
    // Method 3: JavaScript reload (backup)
    async () => {
      logger.info('Refresh method: JS reload');
      await humanSleep(gaussianRandom(300, 100));
      await page.evaluate(() => { window.location.reload(); });
    }
  ];

  // Weighted selection - F5 and Ctrl+R most common
  const weights = [0.45, 0.40, 0.15];
  const rand = Math.random();
  let cumWeight = 0;
  let selectedMethod = methods[0];

  for (let i = 0; i < methods.length; i++) {
    cumWeight += weights[i];
    if (rand < cumWeight) {
      selectedMethod = methods[i];
      break;
    }
  }

  await selectedMethod();
}

// Simulate reading dashboard content after load
async function simulateReadingDashboard(page) {
  const readTime = gaussianRandom(15000, 5000);
  const actualReadTime = clamp(readTime, 8000, 35000);

  logger.info(`Simulating dashboard reading for ${(actualReadTime / 1000).toFixed(1)}s`);

  // Initial pause after page load (looking at content)
  await humanSleep(gaussianRandom(2000, 800));

  // Scroll down to see stats
  await humanScroll(page);
  await humanSleep(gaussianRandom(3000, 1000));

  // Maybe scroll more
  if (Math.random() > 0.4) {
    await humanScroll(page);
    await humanSleep(gaussianRandom(2000, 800));
  }

  // Sometimes scroll back up
  if (Math.random() > 0.5) {
    await page.mouse.wheel(0, -Math.floor(gaussianRandom(300, 100)));
    await humanSleep(gaussianRandom(1500, 500));
  }

  const remainingTime = actualReadTime - 8000;
  if (remainingTime > 0) {
    await simulateIdleBehavior(page, remainingTime);
  }
}

module.exports = {
  sleep,
  humanSleep,
  gaussianRandom,
  clamp,
  getNextRefreshInterval,
  humanMouseMove,
  humanScroll,
  simulateIdleBehavior,
  humanRefresh,
  simulateReadingDashboard
};