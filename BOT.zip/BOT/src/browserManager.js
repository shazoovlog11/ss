const { chromium } = require('playwright-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const path = require('path');
const fs = require('fs');
const logger = require('./logger');
const { gaussianRandom, clamp, humanSleep, sleep } = require('./humanBehavior');

chromium.use(StealthPlugin());

const VIEWPORT_SIZES = [
  { width: 1920, height: 1080, weight: 30 },
  { width: 1366, height: 768, weight: 25 },
  { width: 1536, height: 864, weight: 15 },
  { width: 1440, height: 900, weight: 15 },
  { width: 1280, height: 720, weight: 10 },
  { width: 1600, height: 900, weight: 5 }
];

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0'
];

function getRandomViewport() {
  const totalWeight = VIEWPORT_SIZES.reduce((sum, v) => sum + v.weight, 0);
  let rand = Math.random() * totalWeight;
  for (const size of VIEWPORT_SIZES) {
    rand -= size.weight;
    if (rand <= 0) return size;
  }
  return VIEWPORT_SIZES[0];
}

function getRandomUserAgent() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

// Type text character by character with human-like delays
async function humanType(page, selector, text) {
  await page.click(selector);
  await humanSleep(gaussianRandom(300, 100));
  for (const char of text) {
    await page.type(selector, char, { delay: clamp(gaussianRandom(80, 30), 30, 200) });
  }
}

class BrowserManager {
  constructor(profileDir) {
    this.profileDir = profileDir;
    this.browser = null;
    this.context = null;
    this.page = null;
    this.userAgent = getRandomUserAgent();
    this.viewport = getRandomViewport();

    if (!fs.existsSync(profileDir)) {
      fs.mkdirSync(profileDir, { recursive: true });
    }
  }

  async launch() {
    logger.info('Launching browser with stealth configuration...');

    const launchOptions = {
      headless: true,
      executablePath: this.findChromiumPath(),
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu',
        '--disable-blink-features=AutomationControlled',
        '--disable-features=IsolateOrigins,site-per-process',
        '--disable-infobars',
        '--window-size=' + this.viewport.width + ',' + this.viewport.height,
        '--start-maximized',
        '--disable-extensions-except',
        '--disable-plugins-discovery',
        '--disable-default-apps',
        '--disable-sync',
        '--metrics-recording-only',
        '--mute-audio',
        '--no-default-browser-check',
        '--disable-background-networking',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-breakpad',
        '--disable-client-side-phishing-detection',
        '--disable-component-update',
        '--disable-domain-reliability',
        '--disable-hang-monitor',
        '--disable-ipc-flooding-protection',
        '--disable-popup-blocking',
        '--disable-prompt-on-repost',
        '--disable-renderer-backgrounding',
        '--disable-translate',
        '--force-color-profile=srgb',
        '--hide-scrollbars',
        '--ignore-certifcate-errors',
        '--ignore-certificate-errors',
        '--log-level=3',
        '--password-store=basic',
        '--use-mock-keychain',
        '--export-tagged-pdf',
        '--font-render-hinting=medium'
      ],
      ignoreDefaultArgs: [
        '--enable-automation',
        '--enable-blink-features=IdleDetection'
      ]
    };

    this.browser = await chromium.launchPersistentContext(this.profileDir, {
      ...launchOptions,
      viewport: { width: this.viewport.width, height: this.viewport.height },
      userAgent: this.userAgent,
      locale: 'en-US',
      timezoneId: 'America/New_York',
      geolocation: { longitude: -74.006, latitude: 40.7128 },
      permissions: ['geolocation'],
      colorScheme: 'light',
      deviceScaleFactor: 1,
      isMobile: false,
      hasTouch: false,
      javaScriptEnabled: true,
      acceptDownloads: false,
      ignoreHTTPSErrors: true,
      bypassCSP: true,
      extraHTTPHeaders: {
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Upgrade-Insecure-Requests': '1',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document'
      }
    });

    const pages = this.browser.pages();
    this.page = pages.length > 0 ? pages[0] : await this.browser.newPage();

    await this.applyStealthScripts();

    logger.info(`Browser launched: ${this.userAgent}`);
    logger.info(`Viewport: ${this.viewport.width}x${this.viewport.height}`);

    return { browser: this.browser, context: this.browser, page: this.page };
  }

  findChromiumPath() {
    const paths = [
      '/usr/bin/google-chrome',
      '/usr/bin/google-chrome-stable',
      '/usr/bin/chromium',
      '/usr/bin/chromium-browser',
      '/snap/bin/chromium',
      '/usr/local/bin/chromium'
    ];

    for (const p of paths) {
      if (fs.existsSync(p)) {
        logger.info(`Using Chrome at: ${p}`);
        return p;
      }
    }

    logger.warn('System Chrome not found, using Playwright bundled Chromium');
    return undefined;
  }

  async applyStealthScripts() {
    await this.browser.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
        configurable: true
      });

      Object.defineProperty(navigator, 'plugins', {
        get: () => {
          const makePlugin = (name, filename, desc, mimeTypes) => {
            const plugin = Object.create(Plugin.prototype);
            Object.defineProperty(plugin, 'name', { get: () => name });
            Object.defineProperty(plugin, 'filename', { get: () => filename });
            Object.defineProperty(plugin, 'description', { get: () => desc });
            Object.defineProperty(plugin, 'length', { get: () => mimeTypes.length });
            return plugin;
          };

          const arr = [
            makePlugin('Chrome PDF Plugin', 'internal-pdf-viewer', 'Portable Document Format', []),
            makePlugin('Chrome PDF Viewer', 'mhjfbmdgcfjbbpaeojofohoefgiehjai', '', []),
            makePlugin('Native Client', 'internal-nacl-plugin', '', [])
          ];

          Object.defineProperty(arr, 'item', { value: (i) => arr[i] });
          Object.defineProperty(arr, 'namedItem', { value: (name) => arr.find(p => p.name === name) });
          Object.defineProperty(arr, 'refresh', { value: () => {} });
          return arr;
        },
        configurable: true
      });

      Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
        configurable: true
      });

      Object.defineProperty(navigator, 'platform', {
        get: () => 'Win32',
        configurable: true
      });

      Object.defineProperty(navigator, 'hardwareConcurrency', {
        get: () => 8,
        configurable: true
      });

      Object.defineProperty(navigator, 'deviceMemory', {
        get: () => 8,
        configurable: true
      });

      Object.defineProperty(navigator, 'connection', {
        get: () => ({
          effectiveType: '4g',
          rtt: 50,
          downlink: 10,
          saveData: false
        }),
        configurable: true
      });

      Object.defineProperty(screen, 'colorDepth', { get: () => 24 });
      Object.defineProperty(screen, 'pixelDepth', { get: () => 24 });

      if (!window.chrome) {
        window.chrome = {
          app: { isInstalled: false },
          webstore: {},
          runtime: {
            PlatformOs: { MAC: 'mac', WIN: 'win', ANDROID: 'android', CROS: 'cros', LINUX: 'linux', OPENBSD: 'openbsd' },
            PlatformArch: { ARM: 'arm', X86_32: 'x86-32', X86_64: 'x86-64' },
            RequestUpdateCheckStatus: { THROTTLED: 'throttled', NO_UPDATE: 'no_update', UPDATE_AVAILABLE: 'update_available' },
            OnInstalledReason: { INSTALL: 'install', UPDATE: 'update', CHROME_UPDATE: 'chrome_update', SHARED_MODULE_UPDATE: 'shared_module_update' },
            OnRestartRequiredReason: { APP_UPDATE: 'app_update', OS_UPDATE: 'os_update', PERIODIC: 'periodic' }
          }
        };
      }

      const originalQuery = window.navigator.permissions?.query;
      if (originalQuery) {
        window.navigator.permissions.query = (parameters) => {
          if (parameters.name === 'notifications') {
            return Promise.resolve({ state: Notification.permission });
          }
          return originalQuery(parameters);
        };
      }

      delete document.documentElement.dataset.ltWsVersion;

      const nativeToString = Function.prototype.toString;
      Function.prototype.toString = function() {
        if (this === Function.prototype.toString) return 'function toString() { [native code] }';
        if (this === window.navigator.permissions?.query) return 'function query() { [native code] }';
        return nativeToString.call(this);
      };

      if ('getBattery' in navigator) {
        navigator.getBattery = () => Promise.resolve({
          charging: true,
          chargingTime: 0,
          dischargingTime: Infinity,
          level: 1
        });
      }

      const getParameter = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) return 'Intel Inc.';
        if (parameter === 37446) return 'Intel Iris OpenGL Engine';
        return getParameter.call(this, parameter);
      };

      if (window.Notification) {
        window.Notification.permission = 'default';
      }

      Object.defineProperty(window, 'outerWidth', { get: () => window.innerWidth });
      Object.defineProperty(window, 'outerHeight', { get: () => window.innerHeight + 90 });

      console.log = (...args) => {};
      console.warn = (...args) => {};
    });

    logger.info('Stealth scripts applied');
  }

  async login(username, password) {
    logger.info('Starting Fiverr login process...');

    try {
      // Navigate to Fiverr login page
      await this.page.goto('https://www.fiverr.com/login', {
        waitUntil: 'domcontentloaded',
        timeout: 60000
      });

      await humanSleep(gaussianRandom(2500, 500));

      // Dismiss any overlays/modals first
      const overlaySelectors = [
        '#onetrust-accept-btn-handler',
        '.cookie-consent button',
        '[aria-label="Close"]',
        '.modal-close',
        '[data-testid="close-button"]'
      ];
      for (const sel of overlaySelectors) {
        try {
          const el = await this.page.$(sel);
          if (el && await el.isVisible()) {
            await el.click();
            await humanSleep(500);
          }
        } catch (e) {}
      }

      logger.info('Clicking "Continue with email/username" button...');

      // Click "Continue with email/username" button
      // Try multiple strategies to find the button
      let emailButtonClicked = false;

      // Strategy 1: by text content
      try {
        await this.page.getByText('Continue with email/username', { exact: false }).first().click();
        emailButtonClicked = true;
        logger.info('Clicked email button via text content');
      } catch (e) {}

      // Strategy 2: class-based selector
      if (!emailButtonClicked) {
        try {
          await this.page.click('._1f450qj0');
          emailButtonClicked = true;
          logger.info('Clicked email button via class selector');
        } catch (e) {}
      }

      // Strategy 3: button containing "email" text via evaluate
      if (!emailButtonClicked) {
        try {
          await this.page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'));
            const btn = buttons.find(b => b.textContent.toLowerCase().includes('email') || b.textContent.toLowerCase().includes('username'));
            if (btn) btn.click();
          });
          emailButtonClicked = true;
          logger.info('Clicked email button via evaluate');
        } catch (e) {}
      }

      if (!emailButtonClicked) {
        logger.warn('Could not find email button, trying to proceed directly to inputs...');
      }

      // Wait for input fields to appear
      await humanSleep(gaussianRandom(1500, 400));

      logger.info('Waiting for username/email input field...');
      try {
        await this.page.waitForSelector('#identification-usernameOrEmail', { timeout: 10000 });
      } catch (e) {
        logger.warn('Username field not found with ID, trying alternative selectors...');
      }

      // Type username/email with human-like speed
      logger.info('Entering username/email...');
      try {
        await humanType(this.page, '#identification-usernameOrEmail', username);
      } catch (e) {
        // Fallback: try name attribute
        try {
          await humanType(this.page, '[name="usernameOrEmail"]', username);
        } catch (e2) {
          logger.error('Could not find username input field');
          throw new Error('Username input not found');
        }
      }

      await humanSleep(gaussianRandom(600, 200));

      // Type password
      logger.info('Entering password...');
      try {
        await humanType(this.page, '#identification-password', password);
      } catch (e) {
        try {
          await humanType(this.page, '[name="password"]', password);
        } catch (e2) {
          logger.error('Could not find password input field');
          throw new Error('Password input not found');
        }
      }

      await humanSleep(gaussianRandom(800, 300));

      // Click submit button
      logger.info('Clicking Sign in button...');
      let submitClicked = false;

      // Strategy 1: button[type="submit"]
      try {
        await this.page.click('button[type="submit"]');
        submitClicked = true;
        logger.info('Clicked submit via type=submit');
      } catch (e) {}

      // Strategy 2: by text "Sign in"
      if (!submitClicked) {
        try {
          await this.page.getByText('Sign in', { exact: true }).first().click();
          submitClicked = true;
          logger.info('Clicked submit via "Sign in" text');
        } catch (e) {}
      }

      if (!submitClicked) {
        throw new Error('Could not find submit button');
      }

      // Wait for navigation after login
      logger.info('Waiting for login to complete...');
      await humanSleep(gaussianRandom(4000, 1000));

      try {
        await this.page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 20000 });
      } catch (e) {
        // Navigation might have already completed
      }

      await humanSleep(gaussianRandom(2000, 500));

      const currentUrl = this.page.url();
      logger.info(`Post-login URL: ${currentUrl}`);

      if (currentUrl.includes('/login') || currentUrl.includes('/join')) {
        const pageContent = await this.page.content();
        if (pageContent.toLowerCase().includes('captcha') || pageContent.toLowerCase().includes('arkose')) {
          throw new Error('CAPTCHA detected during login - bot detection triggered');
        }
        throw new Error('Login failed - still on login page. Check credentials or CAPTCHA.');
      }

      logger.info('Login successful!');
      return true;
    } catch (err) {
      logger.error(`Login failed: ${err.message}`);
      throw err;
    }
  }

  getPage() {
    return this.page;
  }

  async close() {
    try {
      if (this.browser) {
        await this.browser.close();
        logger.info('Browser closed');
      }
    } catch (err) {
      logger.error(`Error closing browser: ${err.message}`);
    }
  }
}

module.exports = BrowserManager;
