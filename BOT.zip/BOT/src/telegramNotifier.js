const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');

class TelegramNotifier {
  constructor(botToken, chatId) {
    this.botToken = botToken;
    this.chatId = chatId;
    this.baseUrl = `https://api.telegram.org/bot${botToken}`;
    this.retryAttempts = 3;
    this.retryDelay = 2000;
  }

  async sendMessage(text, parseMode = 'HTML') {
    for (let attempt = 1; attempt <= this.retryAttempts; attempt++) {
      try {
        const response = await axios.post(`${this.baseUrl}/sendMessage`, {
          chat_id: this.chatId,
          text: text,
          parse_mode: parseMode,
          disable_notification: false
        }, { timeout: 15000 });

        if (response.data.ok) {
          logger.info('Telegram message sent');
          return true;
        }
      } catch (err) {
        logger.warn(`Telegram message attempt ${attempt} failed: ${err.message}`);
        if (attempt < this.retryAttempts) {
          await new Promise(r => setTimeout(r, this.retryDelay));
        }
      }
    }
    return false;
  }

  async sendScreenshot(screenshotPath, caption = '') {
    for (let attempt = 1; attempt <= this.retryAttempts; attempt++) {
      try {
        if (!fs.existsSync(screenshotPath)) {
          logger.warn(`Screenshot not found: ${screenshotPath}`);
          return false;
        }

        const form = new FormData();
        form.append('chat_id', this.chatId);
        form.append('photo', fs.createReadStream(screenshotPath));
        if (caption) {
          form.append('caption', caption.substring(0, 1024));
          form.append('parse_mode', 'HTML');
        }

        const response = await axios.post(`${this.baseUrl}/sendPhoto`, form, {
          headers: form.getHeaders(),
          timeout: 30000,
          maxContentLength: Infinity,
          maxBodyLength: Infinity
        });

        if (response.data.ok) {
          logger.info('Screenshot sent to Telegram');
          return true;
        }
      } catch (err) {
        logger.warn(`Telegram screenshot attempt ${attempt} failed: ${err.message}`);
        if (attempt < this.retryAttempts) {
          await new Promise(r => setTimeout(r, this.retryDelay));
        }
      }
    }
    logger.error('Failed to send screenshot to Telegram after all attempts');
    return false;
  }

  async sendStartupMessage() {
    const now = new Date().toISOString();
    const message = `🤖 <b>Fiverr Bot Started</b>\n\n` +
      `⏰ Time: ${now}\n` +
      `🌐 Dashboard: Fiverr Seller Dashboard\n` +
      `✅ Status: Online & Running\n` +
      `🔄 Auto-refresh: Every 50s - 2min\n\n` +
      `<i>Bot is now monitoring your Fiverr presence 24/7</i>`;
    return this.sendMessage(message);
  }

  async sendRefreshNotification(screenshotPath, refreshCount, nextRefreshIn) {
    const now = new Date().toLocaleString('en-US', {
      timeZone: 'America/New_York',
      dateStyle: 'medium',
      timeStyle: 'medium'
    });

    const caption = `✅ <b>Page Refreshed #${refreshCount}</b>\n\n` +
      `⏰ Time: ${now} EST\n` +
      `🔢 Total Refreshes: ${refreshCount}\n` +
      `⏭ Next Refresh: ~${(nextRefreshIn / 1000).toFixed(0)}s\n` +
      `📊 Fiverr Seller Dashboard`;

    return this.sendScreenshot(screenshotPath, caption);
  }

  async sendErrorAlert(errorMessage) {
    const message = `⚠️ <b>Bot Error Alert</b>\n\n` +
      `❌ Error: ${errorMessage.substring(0, 500)}\n` +
      `⏰ Time: ${new Date().toISOString()}\n\n` +
      `<i>Bot will attempt recovery...</i>`;
    return this.sendMessage(message);
  }

  async sendHeartbeat(refreshCount, uptime) {
    const hours = Math.floor(uptime / 3600000);
    const minutes = Math.floor((uptime % 3600000) / 60000);
    const message = `💓 <b>Bot Heartbeat</b>\n\n` +
      `⏱ Uptime: ${hours}h ${minutes}m\n` +
      `🔄 Refreshes: ${refreshCount}\n` +
      `✅ Status: Healthy`;
    return this.sendMessage(message);
  }
}

module.exports = TelegramNotifier;