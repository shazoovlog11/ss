const path = require('path');
const fs = require('fs');
const logger = require('./logger');

class ScreenshotManager {
  constructor(screenshotsDir) {
    this.screenshotsDir = screenshotsDir;
    this.maxScreenshots = 50; // Keep last 50 screenshots

    if (!fs.existsSync(screenshotsDir)) {
      fs.mkdirSync(screenshotsDir, { recursive: true });
    }
  }

  getScreenshotPath(prefix = 'screenshot') {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    return path.join(this.screenshotsDir, `${prefix}_${timestamp}.png`);
  }

  async takeScreenshot(page, prefix = 'refresh') {
    const screenshotPath = this.getScreenshotPath(prefix);

    try {
      await page.screenshot({
        path: screenshotPath,
        fullPage: false,
        type: 'png',
        clip: {
          x: 0,
          y: 0,
          width: page.viewportSize()?.width || 1366,
          height: page.viewportSize()?.height || 768
        }
      });

      logger.info(`Screenshot saved: ${path.basename(screenshotPath)}`);

      // Cleanup old screenshots
      this.cleanupOldScreenshots();

      return screenshotPath;
    } catch (err) {
      logger.error(`Screenshot failed: ${err.message}`);
      return null;
    }
  }

  cleanupOldScreenshots() {
    try {
      const files = fs.readdirSync(this.screenshotsDir)
        .filter(f => f.endsWith('.png'))
        .map(f => ({
          name: f,
          path: path.join(this.screenshotsDir, f),
          mtime: fs.statSync(path.join(this.screenshotsDir, f)).mtime
        }))
        .sort((a, b) => b.mtime - a.mtime);

      if (files.length > this.maxScreenshots) {
        const toDelete = files.slice(this.maxScreenshots);
        toDelete.forEach(file => {
          fs.unlinkSync(file.path);
          logger.debug(`Deleted old screenshot: ${file.name}`);
        });
      }
    } catch (err) {
      logger.warn(`Screenshot cleanup error: ${err.message}`);
    }
  }
}

module.exports = ScreenshotManager;