require('dotenv').config();
const FiverrBot = require('./src/fiverrBot');
const logger = require('./src/logger');

const bot = new FiverrBot();

// Graceful shutdown handlers
process.on('SIGINT', async () => {
  logger.info('Received SIGINT signal');
  await bot.stop();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('Received SIGTERM signal');
  await bot.stop();
  process.exit(0);
});

process.on('uncaughtException', async (err) => {
  logger.error(`Uncaught Exception: ${err.message}`);
  logger.error(err.stack);
  // Don't exit - let the bot try to recover
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error(`Unhandled Rejection at: ${promise}, reason: ${reason}`);
  // Don't exit - let the bot try to recover
});

// Start the bot
logger.info('Initializing Fiverr Bot...');
bot.start().catch(err => {
  logger.error(`Failed to start bot: ${err.message}`);
  process.exit(1);
});