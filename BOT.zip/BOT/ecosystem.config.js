module.exports = {
  apps: [
    {
      name: 'fiverr-bot',
      script: 'index.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      restart_delay: 10000,
      max_restarts: 50,
      min_uptime: '30s',
      env: {
        NODE_ENV: 'production',
        DISPLAY: ':99'
      },
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      log_file: './logs/pm2-combined.log',
      time: true,
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs: true,
      kill_timeout: 30000,
      listen_timeout: 10000,
      node_args: '--max-old-space-size=1024',
      exp_backoff_restart_delay: 100
    }
  ]
};